// document.getElementById('btnProductos'.addEventListener('click', () => {
//     window.location.href = "./products/products.html"
// }))

